<template>
  <div id="Profile">
      <p>我的</p>
  </div>
</template>
<script>
export default {
  name: "Profile"
};
</script>
<style></style>