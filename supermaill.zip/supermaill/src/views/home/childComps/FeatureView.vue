<template>
  <div class="featureView">
    <a href="https://www.mogu.com/">
      <img src="~assets/img/home/recommend_bg.jpg" alt />
    </a>
  </div>
</template>
<script>
export default {
  name: "FeatureView"
};
</script>
<style>
.featureView {
  width: 100%;
}
.featureView img {
  width: 100%;
}
</style>