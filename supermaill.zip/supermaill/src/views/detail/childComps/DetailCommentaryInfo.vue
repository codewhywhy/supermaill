<template>
  <div class="detailCommentaryInfo">
    <h3>评论</h3>
    <ul>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
      <li>我是评论</li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "DetailCommentaryInfo"
};
</script>
<style></style>