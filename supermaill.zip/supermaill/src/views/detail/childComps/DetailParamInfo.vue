<template>
  <div class="detailParamInfo">
    <h3>参数</h3>
    <ul>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
      <li>我是参数</li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "DetailParamInfo"
};
</script>
<style></style>