<template>
  <div id="Category">
    <p>分类</p>
  </div>
</template>
<script>
export default {
  name: "Category"
};
</script>
<style></style>