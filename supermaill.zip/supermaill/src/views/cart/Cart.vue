<template>
  <div id="Cart">
    <p>购物车</p>
  </div>
</template>
<script>
export default {
  name: "Cart"
};
</script>
<style></style>