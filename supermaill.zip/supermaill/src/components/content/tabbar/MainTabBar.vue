<template>
  <tab-bar>
    <tab-bar-item path="/home" :activeColor="this.activeColor">
      <img slot="item-icon" src="~assets/img/tabbar/home.svg" alt />
      <img slot="item-active-icon" src="~assets/img/tabbar/home_active.svg" alt />
      <p slot="item-text">首页</p>
    </tab-bar-item>
    <tab-bar-item path="/category" :activeColor="this.activeColor">
      <img slot="item-icon" src="~assets/img/tabbar/category.svg" alt />
      <img slot="item-active-icon" src="~assets/img/tabbar/category_active.svg" alt />

      <p slot="item-text">分类</p>
    </tab-bar-item>
    <tab-bar-item path="/cart" :activeColor="this.activeColor">
      <img slot="item-icon" src="~assets/img/tabbar/shopcart.svg" alt />
      <img slot="item-active-icon" src="~assets/img/tabbar/shopcart_active.svg" alt />

      <p slot="item-text">购物车</p>
    </tab-bar-item>
    <tab-bar-item path="/profile" :activeColor="this.activeColor">
      <img slot="item-icon" src="~assets/img/tabbar/profile.svg" alt />
      <img slot="item-active-icon" src="~assets/img/tabbar/profile_active.svg" alt />
      <p slot="item-text">我的</p>
    </tab-bar-item>
  </tab-bar>
</template>

<script>
import TabBar from "components/common/tabbar/TabBar";
import TabBarItem from "components/common/tabbar/TabBarItem";
export default {
  name: "mainTabBar",
  data() {
    return {
      activeColor: "deepPink"
    };
  },
  components: {
    TabBar,
    TabBarItem
  }
};
</script>

<style></style>
