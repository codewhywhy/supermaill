<template>
  <div class="backTop">
    <img src="~assets/img/common/top.png" alt="" />
  </div>
</template>
<script>
export default {
  name: "BackTop"
};
</script>
<style>
.backTop {
  position: fixed;
  bottom: 54px;
  right: 10px;
}
.backTop img {
  width: 43px;
  height: 43px;
}
</style>
